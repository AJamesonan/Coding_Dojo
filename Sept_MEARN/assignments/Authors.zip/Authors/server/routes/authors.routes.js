//**************TEMPLATE ROUTES DOC*********** */
// swap Project
// swap Projects
// swap projects
const AuthorsController = require('../controllers/authors.controller');

module.exports = app => {
    app.get('/api/authors', AuthorsController.findAllAuthors);
    app.get('/api/authors/:id', AuthorsController.findOneSingleAuthor);
    app.put('/api/authors/:id', AuthorsController.updateExistingAuthor);
    app.post('/api/authors', AuthorsController.createNewAuthor);
    app.delete('/api/authors/:id', AuthorsController.deleteAnExistingAuthor);
}
