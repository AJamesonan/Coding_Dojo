package com.codingdojo.fruitstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitstoreApplication.class, args);
	}

}
