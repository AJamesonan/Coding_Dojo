package com.codingdojo.fruitstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
